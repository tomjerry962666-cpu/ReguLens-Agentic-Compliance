import unittest
from engine import (
    SAMPLE_REGULATION, SAMPLE_REGULATION_OLD, DEFAULT_CONTROLS, parse_obligations,
    compare_versions, run_pipeline, detect_contradictions, remediate_task, compare_regulatory_sources
)

class PipelineTests(unittest.TestCase):
    def test_extracts_source_grounded_obligations(self):
        obs = parse_obligations(SAMPLE_REGULATION, "test.txt")
        self.assertGreaterEqual(len(obs), 4)
        self.assertTrue(all(o["source_clause"] and o["source_hash"] for o in obs))
    def test_change_detection_marks_modified_periods(self):
        changes = compare_versions(SAMPLE_REGULATION_OLD, SAMPLE_REGULATION)
        self.assertTrue(any(c["change"] == "MODIFIED" for c in changes))
    def test_assessment_creates_gaps_and_tasks_without_falsely_closing_them(self):
        result = run_pipeline(SAMPLE_REGULATION, DEFAULT_CONTROLS, old_text=SAMPLE_REGULATION_OLD,
                              scenario={"remove_evidence": True, "owner_unavailable": True})
        self.assertGreater(result["metrics"]["gaps"], 0)
        self.assertGreater(len(result["plan"]), 0)
        self.assertTrue(all(t["status"] == "OPEN" for t in result["executed_tasks"]))
        self.assertTrue(any(e["action"] == "enforce_closure_gate" and e["status"] == "BLOCKED" for e in result["events"]))
    def test_transient_failure_is_logged_and_recovered(self):
        result = run_pipeline(SAMPLE_REGULATION, DEFAULT_CONTROLS, scenario={"inject_transient_failure": True})
        self.assertTrue(any(e["status"] == "RETRY" for e in result["events"]))
        self.assertTrue(any(e["status"] == "RECOVERED" for e in result["events"]))
    def test_empty_source_stops_safely(self):
        result = run_pipeline("   ", DEFAULT_CONTROLS)
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(result["metrics"]["obligations"], 0)
    def test_unmapped_obligation_is_retained_for_human_review(self):
        result = run_pipeline("The bank must preserve biometric audit artifacts for seven years.", DEFAULT_CONTROLS)
        self.assertEqual(result["metrics"]["obligations"], 1)
        self.assertTrue(result["findings"][0]["control_id"] == "" or result["findings"][0]["mapping_status"] == "REVIEW_REQUIRED")
    def test_scope_mismatch_is_not_automatically_passed(self):
        result = run_pipeline(SAMPLE_REGULATION, DEFAULT_CONTROLS,
                              scope={"jurisdiction":"European Union","entity":"Retail Bank","product":"Payments"})
        self.assertTrue(any(f["assessment"] == "GAP" for f in result["findings"]))
    def test_audit_trace_is_sequenced(self):
        result = run_pipeline(SAMPLE_REGULATION, DEFAULT_CONTROLS)
        seq=[e["sequence"] for e in result["events"]]
        self.assertEqual(seq,list(range(1,len(seq)+1)))


    def test_remediation_workflow_requires_gates_and_closes_eligible_task(self):
        result = run_pipeline(SAMPLE_REGULATION, DEFAULT_CONTROLS,
                              scenario={"remove_evidence": True})
        task = next(t for t in result["executed_tasks"] if t.get("control_id") == "CTRL-EVD-02")
        with self.assertRaises(ValueError):
            remediate_task(result, task["task_id"], "retest")
        remediate_task(result, task["task_id"], "execute")
        self.assertEqual(task["status"], "REMEDIATION_EXECUTED")
        remediate_task(result, task["task_id"], "attach_evidence")
        remediate_task(result, task["task_id"], "attest")
        remediate_task(result, task["task_id"], "retest")
        self.assertEqual(task["status"], "CLOSED")
        self.assertTrue(any(e["action"] == "independent_retest" and e["status"] == "PASS" for e in result["events"]))
        self.assertEqual(result["metrics"]["actions"], sum(t.get("status") != "CLOSED" for t in result["executed_tasks"]))

    def test_cross_source_comparison_flags_different_periods(self):
        primary = "Banks must review privileged access every 90 days."
        secondary = "Banks must review privileged access every 180 days."
        rows = compare_regulatory_sources(primary, "Primary", secondary, "Secondary")
        self.assertTrue(any(r["status"] == "POSSIBLE_CROSS_SOURCE_CONFLICT" for r in rows))

    def test_owner_unavailable_routes_to_fallback(self):
        result = run_pipeline(SAMPLE_REGULATION, DEFAULT_CONTROLS,
                              scenario={"remove_evidence": True, "owner_unavailable": True})
        self.assertTrue(all("fallback" in t["owner"].lower() for t in result["executed_tasks"]))

if __name__ == "__main__": unittest.main()
