import tempfile
import unittest
from pathlib import Path
import service_layer as svc

class ServiceLayerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old_data = svc.DATA_DIR
        self.old_db = svc.DB_PATH
        svc.DATA_DIR = Path(self.tmp.name)
        svc.DB_PATH = svc.DATA_DIR / 'test.db'
        svc.init_db()

    def tearDown(self):
        svc.DATA_DIR = self.old_data
        svc.DB_PATH = self.old_db
        self.tmp.cleanup()

    def test_state_roundtrip(self):
        svc.save_state('x', {'hello': 'world', 'items': [1, 2]})
        self.assertEqual(svc.load_state('x'), {'hello': 'world', 'items': [1, 2]})

    def test_audit_hash_chain(self):
        svc.append_audit('tester', 'ONE', 'case', '1', {'risk': 'high'})
        svc.append_audit('tester', 'TWO', 'case', '1', {'status': 'open'})
        result = svc.verify_audit_chain()
        self.assertTrue(result['valid'])
        self.assertEqual(result['checked'], 2)

    def test_notification_outbox_is_durable(self):
        mid = svc.enqueue_notification('local-demo-inbox', {'subject': 'test'})
        items = svc.list_outbox()
        self.assertEqual(items[0]['message_id'], mid)
        self.assertEqual(items[0]['status'], 'QUEUED')

if __name__ == '__main__':
    unittest.main()
